$(document).ready(function(){   
    $('.datatable').dataTable();
});