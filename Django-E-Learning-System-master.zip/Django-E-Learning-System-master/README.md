# Django-E-Learning-System
This is Django E-Learning Management System(SkyLearn) developed by Noel Moses Mwadende. Version of Django is 3.2 and Python version is 3.7. Watch the complete tutorial from
our YouTube channel https://www.youtube.com/watch?v=UqZYIThWLVk



![alt text](https://github.com/MoTechStore/Django-E-Learning-System/blob/master/thumb.png)
